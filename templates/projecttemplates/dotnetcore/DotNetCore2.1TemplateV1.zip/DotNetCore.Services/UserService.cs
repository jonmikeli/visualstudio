using AutoMapper;
using $ext_safeprojectname$.API.Common.Settings;
using $safeprojectname$.Contracts;
using $safeprojectname$.Model;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class UserService : IUserService
    {
        private string _connectionString = string.Empty;
        private readonly IMapper _mapper;

        public UserService(IOptions<AppSettings> settings, IMapper mapper)
        {
            _connectionString = settings?.Value?.ConnectionString;
            _mapper = mapper;
        }

        public Task<string> CreateAsync(User user)
        {
            throw new NotImplementedException();
        }

        public Task<bool> UpdateAsync(User user)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteAsync(string id)
        {
            throw new NotImplementedException();
        }

        public Task<User> GetAsync(string id)
        {
            throw new NotImplementedException();
        }
    }
}
