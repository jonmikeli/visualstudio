﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Settings
{
    public class AppSettings
    {
        public string ConnectionString { get; set; }
    }
}
