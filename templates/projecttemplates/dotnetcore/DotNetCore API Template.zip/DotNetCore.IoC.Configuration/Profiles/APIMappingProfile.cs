﻿using AutoMapper;
using DC = $ext_safeprojectname$.API.DataContracts;
using S = $ext_safeprojectname$.Services.Model;

namespace $safeprojectname$.Profiles
{
    public class APIMappingProfile : Profile
    {
        public APIMappingProfile()
        {
            CreateMap<S.User, DC.User>();
            CreateMap<S.Adress, DC.Adress>();
        }
    }
}
