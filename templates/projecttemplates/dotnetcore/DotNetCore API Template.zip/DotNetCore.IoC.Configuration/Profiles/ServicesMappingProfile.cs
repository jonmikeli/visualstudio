﻿using AutoMapper;

namespace $safeprojectname$.Profiles
{
    public class ServicesMappingProfile : Profile
    {
        public ServicesMappingProfile()
        {
            //TODO: complete with business and repository mappings
        }
    }
}
